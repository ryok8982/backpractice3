﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using Microsoft.Win32;
using System.Xml.Linq;

namespace backPractice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CS_AutoChecked(object sender, RoutedEventArgs e)
        {
            CS_max.IsChecked = false;
            CS_min.IsChecked = false;
        }

        private void CS_MinChecked(object sender, RoutedEventArgs e)
        {
            CS_auto.IsChecked = false;
            CS_max.IsChecked = false;
        }

        private void CS_MaxChecked(object sender, RoutedEventArgs e)
        {
            CS_auto.IsChecked = false;
            CS_min.IsChecked = false;
        }

        private void button_write_Click(object sender, RoutedEventArgs e)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.Encoding = Encoding.UTF8;

            XmlWriter xmlWriter = XmlWriter.Create(TextBox1.Text + ".xml", settings);

            xmlWriter.WriteStartElement("InspectionMethod");

            xmlWriter.WriteStartElement("comparisonSetting");
            xmlWriter.WriteStartElement("name"); 
            xmlWriter.WriteValue("autoAdjustment");
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("content");
            int IntTest = Convert.ToInt32(CS_auto.IsChecked);
            xmlWriter.WriteValue(IntTest);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("comparisonSetting");
            xmlWriter.WriteStartElement("name");
            xmlWriter.WriteValue("MaxValue");
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("content");
            int IntMax = Convert.ToInt32(CS_max.IsChecked);
            xmlWriter.WriteValue(IntMax);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("comparisonSetting");
            xmlWriter.WriteStartElement("name");
            xmlWriter.WriteValue("MinValue");
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("content");
            int IntMin = Convert.ToInt32(CS_min.IsChecked);
            xmlWriter.WriteValue(IntMin);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("comparisonSetting");
            xmlWriter.WriteStartElement("name");
            xmlWriter.WriteValue("MaximumResolution");
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("content");
            xmlWriter.WriteValue(CS_maxResolution.Text);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteEndElement(); // end item


            xmlWriter.Flush();

            MessageBox.Show("Write Complete!");
        }

        private void button_reference_Click(object sender, RoutedEventArgs e)
        {
            // ダイアログのインスタンスを生成
            var dialog = new OpenFileDialog();

            // ファイルの種類を設定
            dialog.Filter = "テキストファイル (*.xml)|*.xml|全てのファイル (*.*)|*.*";

            

            // ダイアログを表示する
            if (dialog.ShowDialog() == true)
            {
                // 選択されたファイル名 (ファイルパス) をメッセージボックスに表示
                //xmlファイルを指定する
                string filename = dialog.FileName;
                var doc = XElement.Load(filename);

                var cs = from p in doc.Elements("comparisonSetting") select p;


                CS_auto.IsChecked = Convert.ToBoolean(cs.Element("content").Value);
                MessageBox.Show(cs);
            }
        }
    }
}
